# StayLedger update — 4 November 2026

## What this update delivers
1. Bank CSV credit imports and explicit one-deposit-to-many-bookings allocation. Duplicate IDs are checked. Differences are shown, not silently written off. Separate deposits for one booking and foreign currency are not supported yet.
2. Booking month/property filters and bank month filters. Booking reports use booking date; bank reports use deposit date. The complete booking list remains available when allocating deposits across periods.
3. Needs attention list for unmatched bookings, with notes. Matched deposits with differences show their difference in the bank list and bank export. A resolved/reviewed status is not implemented.
4. Reusable column layout saved to this browser. This is not a verified Airbnb/Booking.com preset: real financial exports are needed to validate platform-specific formats.
5. Monthly booking detail, bank reconciliation and unmatched-booking exports; full JSON backup/restore includes matches and notes. Existing provider summary and draft Xero sales exports remain available. No automatic GST calculation.
6. The existing private pilot account code is retained. Independent client sign-up, cloud saving of new bank records and Stripe billing are NOT implemented or activated. See CLIENT-ACCOUNTS-AND-BILLING.md for the required launch work. Do not sell access as a finished subscription yet.

## A. Upload the working website update
1. Download and unzip this package on your computer.
2. Open your existing Zero Issues repository in GitHub. Download a backup first: Code > Download ZIP.
3. Locate the directory that currently contains the live homepage index.html. Your hosting may publish the repository root or the website directory; use the SAME location as before.
4. Choose Add file > Upload files. Upload the CONTENTS of this package's website folder into that location. Do not upload the outer package or developer-source into the public website.
5. Confirm website/assets/reconcile.js is included and website/stayledger/demo.html is replaced. Retain any newer unrelated changes from your live repository.
6. Commit with a message such as 'Add StayLedger bank matching and monthly reports'. Wait for the existing host's deployment to succeed.
7. Open https://zeroissues.co.nz/stayledger/demo.html and refresh. No DNS changes are required for these website file edits.
8. Your existing private pilot link is unchanged. This update does not update its deployed server automatically. Use the browser demo link to try these improvements.

## B. Try the new workflow
1. Open StayLedger's browser demo. Load sample workspace.
2. Open Bank matching. Download the bank template. Replace its example with id BANK-DEMO-1, date 2026-10-31, description Sample payout, amount 1300.50.
3. Import it. Select DEMO-1042 (714) and DEMO-1043 (586.50). Hold Ctrl on Windows or Command on Mac to select both. Confirm selected bookings. Expected 1300.50, received 1300.50, difference zero.
4. Remove the match if you selected the wrong bookings. Match again.
5. Set bank month to October 2026. Use the property filter for booking reports and the attention list. Bank reconciliation always reports the whole selected bank month, including deposits across properties.
6. Add review notes for unmatched bookings.
7. Download booking detail, bank reconciliation and outstanding items. Review all three together. A matched deposit may still have a non-zero difference.
8. Download full workspace backup before refreshing or closing. Restore it next time to continue. Keep backups securely because they contain financial data.
9. Clear sample data before importing real records. Do not mix sample and client data.
10. For bookings, map each CSV field once, click Save column layout, and use Apply saved layout on the next export with identical headings. Save separate exported backups per client.

## C. What to send next
An anonymised real financial booking CSV, a corresponding bank CSV, the GitHub repository URL and confirmation of the current hosting service. Remove guest names, email addresses and account numbers. Keep column headings and representative amounts/dates.

## Verification
JavaScript syntax and automated DOM workflow checks are recorded in QA-RESULTS.md. No production deployment, real provider import, real payment or live client sign-in has been verified. This package is an update for your existing GitHub site, not a new hosting deployment.
