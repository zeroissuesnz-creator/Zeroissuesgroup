# StayLedger application source handover

This is the complete tracked source of the existing private pilot at the time of export. Dependencies, build output, runtime files, secrets, Git history and live database records are omitted. A clean logical hosting manifest is included with no project identity; it is not an instruction to create or modify the existing deployment.

## What works

Financial CSV mapping, validation, duplicate handling, payout reconciliation, reconciliation exports, draft Xero gross-sales export, authenticated per-user D1 workspace save/load, revision conflict protection and install metadata. Saved trial/plan preferences do not represent paid subscriptions. API authorization derives user identity from the Sites trusted dispatch headers.

## Development

Node >=22.13.0 and the included pnpm lockfile are used. Run `pnpm install --frozen-lockfile`, then `pnpm run dev` for development or `pnpm run build` to build. Read the included starter README for local profile and D1 migration requirements. The maintained Sites workflow is the supported production deployment route for this source.

Do NOT put this folder into a static Pages output directory. Do NOT expose an ordinary server that blindly trusts browser-supplied `oai-authenticated-user-id` headers. Outside Sites, those headers require replacement with a trusted, verified authentication provider and server-side authorization. Existing trusted-header behavior depends on the managed platform boundary. A plain Cloudflare Worker deployment is not a drop-in replacement for that boundary.

D1 schema: db/schema.ts; initial migration: drizzle/0000_equal_caretaker.sql. Live data must be migrated separately if hosting changes. The saved application code is not a database backup.

## Not implemented

Stripe Checkout, webhook signature verification, payment portal, trial timers, paid entitlements, accountant-to-client sharing, live booking providers and direct Xero OAuth/posting. No subscription can be purchased by uploading this source. See BILLING-SETUP.md.

## Public website integration

Use the separate website folder for the main site and product branches. Its config.js links to the current private pilot. Keep this full app source in a separate private repository when developing it independently. In a repository containing the whole download package, publish ONLY `website`.
