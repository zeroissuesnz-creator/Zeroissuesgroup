# StayLedger — Zero Issues add-on

Offer configured in the pilot UI:
- Monthly plan: NZD 10.99 including GST (1099 cents total).
- Price presentation: NZD 9.56 excluding GST + NZD 1.43 GST.
- Proposed free trial: 14 days (assumed pending owner review).
- One product; other Zero Issues products should retain separate entitlements.
- No live Stripe checkout, trial timer, recurring subscription, cancellation portal or entitlement enforcement exists yet.

## Stripe activation work still required

Use the existing Zero Issues Stripe account. Create a StayLedger subscription product, monthly NZD price of 1099 cents, with inclusive tax treatment where applicable. Confirm Zero Issues GST registration and tax configuration before charging. Do not create a second price merely for the inclusive/exclusive display switch.

Connect through server-side secrets only. Decide whether the trial collects a card; communicate what happens at trial expiry clearly. Configure Checkout and billing portal, verify signed webhooks, store product-specific customer/subscription identity, and enforce trial/subscription access on the server. Never grant paid access from a checkout success URL or client-side plan preference. Test trial expiry, payment success/failure, cancellation, repeated webhook delivery and cross-user isolation before public launch.

The current accountingBasis preference does not convert amounts or apply GST to bookings. Input files must retain actual gross totals for payout reconciliation. Source-specific marketplace GST and Xero tax treatment require separate implementation/review.

## Website integration

The pilot remains private. After billing and client access are tested, link a StayLedger product card on zeroissues.co.nz to the deployed app. Do not embed private account pages in an unrelated-domain iframe. A public sales page and private authenticated workspace should have distinct purposes. No changes have been made to zeroissues.co.nz in this update.
