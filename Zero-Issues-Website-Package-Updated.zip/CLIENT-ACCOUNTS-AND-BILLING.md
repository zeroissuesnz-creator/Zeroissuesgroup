# Client accounts and billing: remaining launch work

This is a launch checklist, not an implemented payment integration. The current pilot relies on managed ChatGPT authentication and must not be deployed as an ordinary public Worker trusting user ID request headers.

## Isabel's steps
1. Publish and test the free browser workflow using READ-ME-FIRST.md. Do not collect subscription payments yet.
2. Supply the existing GitHub repository URL and identify whether the live site uses Cloudflare Pages or GitHub Pages. No passwords or secret keys in chat or GitHub.
3. Decide where the paid app will live, e.g. app.zeroissues.co.nz. Retain the main Zero Issues website and its other branches.
4. Once the public-client server architecture is implemented, configure a verified authentication provider with email verification/password reset, per-client database access and secure sessions. The existing private pilot is not independent public-client sign-up.
5. In Stripe TEST mode create StayLedger Monthly, NZD 10.99 recurring monthly. Configure a 14-day trial in the server-side Checkout integration. Confirm the business's GST registration and price/tax configuration before enabling live charges. The existing display switch shows the same total inclusive/exclusive; it does not change imported accounting amounts.
6. Store Stripe secret and webhook signing secret in server environment settings only. Never put them in assets/config.js or public GitHub files.
7. The implementation must create Checkout sessions for the verified signed-in client; verify webhook signatures; store unique event IDs and customer/subscription associations; reconcile out-of-order events; enforce access server-side; provide the Stripe customer portal; and preserve read/export access when a subscription ends.
8. Test sign-up, account isolation between two users, cloud backup of bookings/banks/matches/notes, trial expiry, successful/failed payments, cancellation, duplicate webhook delivery and customer portal access. Browser return URLs must never grant subscription access.
9. Publish terms, privacy information, subscription cancellation/refund terms and support contact, then switch to LIVE Stripe configuration and repeat a controlled end-to-end check.

## Work not completed in this package
Public authentication, database changes for bank matches, subscription routes, webhook processing, entitlement enforcement, and live deployment. These need implementation against the chosen server host and account configuration. The price display and disabled trial button are retained honestly; they do not take payment.
