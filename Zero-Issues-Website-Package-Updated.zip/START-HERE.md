# Zero Issues website — start here

Prepared 2 November 2026. This is a download package; your current domain and GitHub repository have not been changed.

## What you have

- `website/index.html`: the new main home page, with two branches.
- `website/bookkeeping/index.html`: bookkeeping and Xero assistance.
- `website/stayledger/index.html`: StayLedger product page, pricing toggle and FAQs.
- `website/stayledger/demo.html`: working, standalone browser demo with CSV import and accounting exports. No login, persistent saving or billing.
- `website/assets/`: shared styles, configuration and scripts. No images or extra downloads required.
- `UPLOAD-INSTRUCTIONS.html`: readable step-by-step GitHub, hosting and domain instructions. Open this file in a browser.
- `developer-source/stayledger/`: full tracked source snapshot of the separately hosted app, including account-based saving and database migration. Not a static website; read its HANDOVER.md.

## Recommended structure

www.zeroissues.co.nz → new main home page
www.zeroissues.co.nz/bookkeeping/ → personal bookkeeping and Xero service
www.zeroissues.co.nz/stayledger/ → public StayLedger product branch
www.zeroissues.co.nz/stayledger/demo.html → free, tab-only demo
Hosted StayLedger pilot → existing private app link; public paid access is not configured

A branch here means a section/folder of the website, not a Git branch.

## Important before replacing the current site

Download a backup of your current website repository. This package is a new design, not a byte-for-byte migration of the existing site. The live website was not accessible through the lookup used, and the GitHub connection returned no repositories. Contact details were taken from an earlier Zero Issues HTML file: zeroissuesnz@gmail.com. Confirm this is still your preferred address. Existing logos, Tawk.to chat, analytics and any old integrations have not been carried over. Keep your original assets until you have reviewed what you need.

## Editable settings

Change the public contact email and hosted app link in `website/assets/config.js`. Keep it public-data-only. All mail buttons open the visitor's email program; there is no hosted contact form.

The subscription price has been interpreted as NZD 10.99 INCLUDING GST. Its rounded exclusive presentation is NZD 9.56 + NZD 1.43 GST. The 14-day trial is a proposed duration, not an active timer. No public subscription, payment collection or direct booking/Xero connection is implemented.

The app's separate accounting GST setting remains a preference only. It does not convert CSV values or choose Xero tax treatment.

## Hosting choice

Use GitHub for storing/editing the code, with Cloudflare Pages (or an equivalent commercial-capable host) to publish it. Do not use GitHub Pages for this paid SaaS/business setup: its published terms exclude websites primarily directed at facilitating commercial transactions or commercial SaaS. GitHub Pages also cannot run this app's server/database code.

Keep the current managed app backend where it is while publishing this new public website. Exporting its source does not export its hosted user records, platform sign-in or billing services. Moving it to another backend is a separate migration.
